__version__ = '0.17.0a0+4433680'
git_version = '4433680aa57439ed684f9854fac3443b76e03c03'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
